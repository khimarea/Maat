int main()
{
  int i;
  for (i = 0; i < 10; i++)
  {
    printf("School\n");
  }
  return 0;
}
